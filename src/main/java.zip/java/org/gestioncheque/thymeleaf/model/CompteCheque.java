package org.gestioncheque.thymeleaf.model;

public class CompteCheque {
	private String numCq;
	private long numCli;
	
	public CompteCheque() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getNumCq() {
		return numCq;
	}
	public void setNumCq(String numCq) {
		this.numCq = numCq;
	}
	public long getNumCli() {
		return numCli;
	}
	public void setNumCli(long numCli) {
		this.numCli = numCli;
	}
	public CompteCheque(String numCq, long numCli) {
		super();
		this.numCq = numCq;
		this.numCli = numCli;
	}
	
	

}

package org.gestioncheque.thymeleaf.model;

import java.io.Serializable; 

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import com.sun.istack.NotNull;
@Entity
public class Compte implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue
	private long id;
	private long numCli;
	@NotNull
	private String lib;
	@NotNull
	private int numOrg;
	private String typeCli;
	private int numCpte;
	private String nom;
	public Compte() {
		super();	
	}
	
	public Compte(long numCli, String lib, int numOrg, String typeCli) {
		super();
		this.numCli = numCli;
		this.lib = lib;
		this.numOrg = numOrg;
		this.typeCli = typeCli;
	}

	public long getNumCli() {
		return numCli;
	}
	public void setNumCli(long numCli) {
		this.numCli = numCli;
	}
	public String getLib() {
		return lib;
	}
	public void setLib(String lib) {
		this.lib = lib;
	}
	public int getNumOrg() {
		return numOrg;
	}
	public void setNumOrg(int numOrg) {
		this.numOrg = numOrg;
	}
	public String getTypeCli() {
		return typeCli;
	}
	public void setTypeCli(String typeCli) {
		this.typeCli = typeCli;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public int getNumCpte() {
		return numCpte;
	}

	public void setNumCpte(int numCpte) {
		this.numCpte = numCpte;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

}

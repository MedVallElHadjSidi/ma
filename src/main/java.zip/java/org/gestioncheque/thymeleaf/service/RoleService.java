package org.gestioncheque.thymeleaf.service;

import java.util.List;

import javax.management.relation.Role;

public interface RoleService {
	public Role addUser(Role role);
	public List<Role> listUser();

}

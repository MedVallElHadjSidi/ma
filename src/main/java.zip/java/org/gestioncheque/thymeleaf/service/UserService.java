package org.gestioncheque.thymeleaf.service;

import org.gestioncheque.thymeleaf.model.User;

public interface UserService {

	 User findByUsernameOrEmail(String usernameOrEmail);
	 User findByUserName(String userName);
}

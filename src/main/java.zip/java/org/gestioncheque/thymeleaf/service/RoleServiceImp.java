package org.gestioncheque.thymeleaf.service;

public class RoleServiceImp {
	/*
	 * @Autowired RoleRepository roleRepository;
	 * 
	 * @Override public Role addUser(Role role) { // TODO Auto-generated method stub
	 * return roleRepository.save(role); }
	 * 
	 * @Override public List<Role> listUser() { // TODO Auto-generated method stub
	 * return roleRepository.findAll(); }
	 */
}

package org.gestioncheque.thymeleaf.service;

import java.io.FileNotFoundException;

import net.sf.jasperreports.engine.JRException;

public interface ReportService {
	public String exportreport(long numcc) throws Exception;

}

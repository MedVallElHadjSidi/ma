package org.gestioncheque.thymeleaf.controller;

import java.util.List;
import java.util.Optional;

import org.gestioncheque.thymeleaf.model.Compte;
import org.gestioncheque.thymeleaf.service.CompteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
@Controller
@RequestMapping("/comptes")
public class CompteController {
	@Autowired
	CompteService compteservice;
	@GetMapping("/listecomptes")
	public String getlistcheque(Model model) {
		
		List<Compte> listeCmp=compteservice.listeComptes();
		
		model.addAttribute("comptes",listeCmp);
		
		return "listeCompte";
	}
	@RequestMapping(value="/formcompte",method=RequestMethod.GET)
	public String formcmp(Model model) {
		model.addAttribute("compte",new Compte());
		return "formCompte";
	} 
	@RequestMapping(value="/SaveCompte",method=RequestMethod.POST)
	public String savecmp(Compte cmp) {
		compteservice.addCompte(cmp);
		return "redirect:listecomptes";
	}
	@RequestMapping("/edit/{id}")
	public ModelAndView showEditProductForm(@PathVariable(name="id") long id) {
		ModelAndView mav=new ModelAndView("edit_compte");
		Optional<Compte> compte=compteservice.get(id);
		mav.addObject("compte",compte);
		return mav;
	} 
	@RequestMapping("/delete/{id}")
	public String deletecopmte(@PathVariable(name="id") long id) {
		compteservice.delete(id);
		return "redirect:/comptes/listecomptes";
	}
	
}

package org.gestioncheque.thymeleaf.controller;

import java.util.List;

import org.gestioncheque.thymeleaf.model.CarnetCheque;
import org.gestioncheque.thymeleaf.model.Cheque;
import org.gestioncheque.thymeleaf.model.Compte;
import org.gestioncheque.thymeleaf.service.CarnetChequeReportService;
import org.gestioncheque.thymeleaf.service.CarnetChequeService;
import org.gestioncheque.thymeleaf.service.ChequeService;
import org.gestioncheque.thymeleaf.service.CompteService;
import org.gestioncheque.thymeleaf.service.ReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/carnetcheques")
public class CarnetChequeController {
	@Autowired
	CarnetChequeService carnetchequeservice;
	@Autowired
	CompteService compteservice;
	@Autowired
	ChequeService chequeservice;
	
	@Autowired
	CarnetChequeReportService carnetChequeReportService;
	@Autowired
	ReportService reportService;
	@GetMapping("/ajoutercarnetcheque")
	public String ajoutcarnetcheque() {
		return "AjoutCarnetCheque";
	}
	@GetMapping("/listecarnetcheques")
	public String getlistcarnetcheque(Model model) {
		
		List<CarnetCheque> listeCCQ=carnetchequeservice.listeCarnetCheque();
		
		model.addAttribute("carnetcheque",listeCCQ);
		
		return "listeCarnetCheque";
	}
	@RequestMapping(value="/formcarnetcheque",method=RequestMethod.GET)
	public String formccq(Model model) {
		model.addAttribute("carnetcheque",new CarnetCheque());
		model.addAttribute("compte",new Compte());
		return "formCarnetCheque";
	}
	@RequestMapping(value="/SaveCarnetCheque",method=RequestMethod.POST)
	public String savecq(CarnetCheque ccq) {
		carnetchequeservice.addCarnetCheque(ccq);
		return "redirect:listecarnetcheques";
	}
	@RequestMapping("/edit/{id}")
	public ModelAndView showEditProductForm(@PathVariable(name="id") long id) {
		ModelAndView mav=new ModelAndView("edit_carnetcheque");
		CarnetCheque carnetcheque=carnetchequeservice.get(id);
		mav.addObject("carnetcheque",carnetcheque);
		return mav;
	}
	@RequestMapping("/delete/{id}")
	public String deletecheque(@PathVariable(name="id") long id) {
		CarnetCheque carnetcheque=carnetchequeservice.get(id);
		List<Cheque> listcheque=chequeservice.search(id);
		for(int i=0;i<=carnetcheque.getNbreCQ();i++) {
	    chequeservice.delete(listcheque.get(i).getId());
		}
	    carnetchequeservice.delete(id);
		return "redirect:/carnetcheques/listecarnetcheques";
	}
	
	@GetMapping("/search")
	public String search(Model model, @Param("keyword") Long keyword) {
	
		List<Compte> listeCpte=carnetchequeservice.search(keyword);
		System.out.print("Taille liste cpte : " + listeCpte.size());
		if (listeCpte.size()==0) {
			
			model.addAttribute("error", "Compte inexistant");
			
			return "redirect:ajoutercarnetcheque";
		} 
		
		model.addAttribute("compte",listeCpte.get(0));
		model.addAttribute("keyword", keyword);
		model.addAttribute("carnetCheque",new CarnetCheque());
		return "ListeCompteCarnetCheque";
	}
	@RequestMapping("/listcheque/{id}")
	public String listecheque(Model model,@PathVariable(name="id") long id) {
		List<Cheque> listeChq=carnetchequeservice.listecheque(id);
		model.addAttribute("cheque",listeChq);
		return "listeCheque";
	}
	
	@RequestMapping("/imprimer/{id}")
	public String imprimer(Model model,@PathVariable(name="id") long id) throws Exception {
	 
		/*
		 * reportService.exportreport(id); return "listeCheque";
		 */
		
		String generer=carnetChequeReportService.generateReport(id);
		List<Cheque> listeChq=carnetchequeservice.listecheque(id);
		model.addAttribute("cheque",listeChq);
		model.addAttribute("generer",generer);
		
		return "report";
		 
		
	
	}
	
	
	
}

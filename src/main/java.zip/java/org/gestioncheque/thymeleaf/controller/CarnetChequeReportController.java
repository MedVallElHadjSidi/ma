package org.gestioncheque.thymeleaf.controller;
import org.gestioncheque.thymeleaf.service.CarnetChequeReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
@Controller
public class CarnetChequeReportController {
	@Autowired
	CarnetChequeReportService carnetChequeReportService;
	/*
	 * @GetMapping("/report") public String ccReport() {
	 * 
	 * return carnetChequeReportService.generateReport(218); }
	 */

}

package org.gestioncheque.thymeleaf.controller;

import java.util.List;

import org.gestioncheque.thymeleaf.model.BordereauVirement;
import org.gestioncheque.thymeleaf.model.CarnetBordereauVirement;
import org.gestioncheque.thymeleaf.model.Compte;
import org.gestioncheque.thymeleaf.service.BordereauVirementService;
import org.gestioncheque.thymeleaf.service.CarnetBordereauVirementService;
import org.gestioncheque.thymeleaf.service.CompteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/carnetbordereauvirements")
public class CarnetBordereauVirementController {
	@Autowired
	CarnetBordereauVirementService carnetbordereauvirementservice;
	@Autowired
	CompteService compteservice;
	@Autowired
	BordereauVirementService bordereauvirementservice;

	@GetMapping("/ajoutercarnetbordereauvirement")
	public String ajoutcarnetbordereauvirement() {
		return "AjoutCarnetBordereauVirement";
	}
	@GetMapping("/listecarnetbordereauvirements")
	public String getlistcarnetbordereauvirement(Model model) {
		
		List<CarnetBordereauVirement> listeCBV=carnetbordereauvirementservice.listeCarnetBordereauVirement();
		
		model.addAttribute("carnetbordereauvirement",listeCBV);
		
		return "listeCarnetBordereauVirement";
	}
	@GetMapping("/search")
	public String search(Model model, @Param("keyword") Long keyword) {
		List<Compte> listeCpte=carnetbordereauvirementservice.search(keyword);
		System.out.print("Taille liste cpte : " + listeCpte.size());
		if (listeCpte.size()==0) {
			
			model.addAttribute("error", "Compte inexistant");
			
			return "redirect:ajoutercarnetcheque";
		} 
		
		model.addAttribute("compte",listeCpte.get(0));
		model.addAttribute("keyword", keyword);
		model.addAttribute("carnetbordereauvirement",new CarnetBordereauVirement());
		return "ListeCompteCarnetBordereauVirement";
	}
	@RequestMapping(value="/Savecarnetbordereauvirement",method=RequestMethod.POST)
	public String savecq(CarnetBordereauVirement cbv) {
		carnetbordereauvirementservice.addCarnetBordereauVirement(cbv);
		return "redirect:listecarnetbordereauvirements";
	}
	@RequestMapping("/listbordereauvirement/{id}")
	public String listecheque(Model model,@PathVariable(name="id") long id) {
		List<BordereauVirement> listebv=carnetbordereauvirementservice.listebv(id);
		model.addAttribute("bordereauvirement",listebv);
		return "listeBordereauVirement";
	}
	@RequestMapping("/edit/{id}")
	public ModelAndView showEditProductForm(@PathVariable(name="id") long id) {
		ModelAndView mav=new ModelAndView("edit_carnetbordereauvirement");
		CarnetBordereauVirement carnetbordereauvirement= carnetbordereauvirementservice.get(id);
		mav.addObject("carnetbordereauvirement",carnetbordereauvirement);
		return mav;
	}
	@RequestMapping("/delete/{id}")
	public String deletecheque(@PathVariable(name="id") long id) {
		CarnetBordereauVirement carnetbordereauvirement=carnetbordereauvirementservice.get(id);
		List<BordereauVirement> listbordereauvirement=bordereauvirementservice.search(id);
		for(int i=0;i<=carnetbordereauvirement.getNbreBV();i++) {
			bordereauvirementservice.delete(listbordereauvirement.get(i).getId());
		}
		carnetbordereauvirementservice.delete(id);
		return "redirect:/carnetbordereauvirements/listecarnetbordereauvirements";
	}
	

}
